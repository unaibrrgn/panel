# MVC_Simple
Ejemplo de MVC simple para una aplicación de escritorio
